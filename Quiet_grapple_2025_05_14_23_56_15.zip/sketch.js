let grid = [];
let gridSize = 10;
let tileSize;
let playerMoney = 10;
let currentPlant = 'wheat'; // Default plant
let selectedTile = null; // Track the currently selected tile for selling

let plants = {
  'wheat': { cost: 2, sellPrice: 5, harvestTime: 600, image: null }, // 10 segundos
  'carrot': { cost: 5, sellPrice: 12, harvestTime: 1200, image: null }, // 20 segundos
  'strawberry': { cost: 8, sellPrice: 20, harvestTime: 1800, image: null } // 30 segundos
};
let plantImages = {};

function preload() {
  plants['wheat'].image = loadImage('https://i.imgur.com/Y4744vs.png'); // Replace with wheat image URL
  plants['carrot'].image = loadImage('https://i.imgur.com/8f8RQr4.png'); // Replace with carrot image URL
  plants['strawberry'].image = loadImage('https://i.imgur.com/e917fOA.png'); // Replace with strawberry image URL
}

function setup() {
  createCanvas(400, 450); // Increased height for the sell button
  tileSize = width / gridSize;

  // Initialize the grid
  for (let i = 0; i < gridSize; i++) {
    grid[i] = [];
    for (let j = 0; j < gridSize; j++) {
      grid[i][j] = { planted: null, growth: 0 };
    }
  }

  // Create UI elements
  createPlantButton('wheat', 10, height - 60);
  createPlantButton('carrot', 80, height - 60);
  createPlantButton('strawberry', 170, height - 60);
  createSellButton(260, height - 60);
  textSize(16);
}

function draw() {
  background(120);

  // Draw the grid
  for (let i = 0; i < gridSize; i++) {
    for (let j = 0; j < gridSize; j++) {
      stroke(100);
      fill(selectedTile && selectedTile.x === i && selectedTile.y === j ? 200 : 180); // Highlight selected tile
      rect(i * tileSize, j * tileSize, tileSize, tileSize);

      let tile = grid[i][j];
      if (tile.planted) {
        let plantData = plants[tile.planted];
        if (plantData.image) {
          image(plantData.image, i * tileSize, j * tileSize, tileSize, tileSize);
        } else {
          fill(0, 150, 0);
          rect(i * tileSize, j * tileSize, tileSize, tileSize);
          fill(255);
          textAlign(CENTER, CENTER);
          text(tile.planted.charAt(0).toUpperCase(), i * tileSize + tileSize / 2, j * tileSize + tileSize / 2);
        }

        if (tile.growth < plantData.harvestTime) {
          tile.growth++;
          fill(255, 255, 0, 100);
          rect(i * tileSize, j * tileSize + tileSize * (1 - tile.growth / plantData.harvestTime), tileSize, tileSize * (tile.growth / plantData.harvestTime));
        } else if (tile.growth >= plantData.harvestTime) {
          // Indica que a planta está pronta para colheita
          fill(255, 255, 255, 50);
          rect(i * tileSize, j * tileSize, tileSize, tileSize);
        }
      }
    }
  }

  // Display money
  fill(255);
  textAlign(LEFT, TOP);
  text(`Money: $${playerMoney}`, 10, 10);
  text(`Planting: ${currentPlant}`, 10, 30);
  if (selectedTile) {
    let tileData = grid[selectedTile.x][selectedTile.y];
    if (tileData.planted) {
      text(`Selected: ${tileData.planted.charAt(0).toUpperCase() + tileData.planted.slice(1)} (Click 'Sell' to sell)`, 10, 50);
    } else {
      text("Selected: Empty Tile", 10, 50);
    }
  }
}

function mouseClicked() {
  let gridX = floor(mouseX / tileSize);
  let gridY = floor(mouseY / tileSize);

  if (gridY < gridSize) { // Ensure click is within the grid
    if (gridX >= 0 && gridX < gridSize && gridY >= 0 && gridY < gridSize) {
      let tile = grid[gridX][gridY];
      selectedTile = { x: gridX, y: gridY }; // Select the clicked tile
      if (!tile.planted) {
        tryPlant(gridX, gridY);
        selectedTile = null; // Deselect after planting
      } else if (plants[tile.planted].growth >= plants[tile.planted].harvestTime) {
        harvest(gridX, gridY);
        selectedTile = null; // Deselect after harvesting
      }
    }
  }
}

function tryPlant(x, y) {
  let plantCost = plants[currentPlant].cost;
  if (playerMoney >= plantCost) {
    grid[x][y].planted = currentPlant;
    grid[x][y].growth = 0;
    playerMoney -= plantCost;
  } else {
    console.log("Não tem dinheiro suficiente!");
  }
}

function harvest(x, y) {
  let plantType = grid[x][y].planted;
  let sellPrice = plants[plantType].sellPrice;
  playerMoney += sellPrice;
  grid[x][y].planted = null;
  grid[x][y].growth = 0;
  console.log(`Colheu ${plantType} por $${sellPrice}`);
}

function createPlantButton(plantName, x, y) {
  let button = createButton(plantName.charAt(0).toUpperCase() + plantName.slice(1));
  button.position(x, y);
  button.mousePressed(() => {
    currentPlant = plantName;
    selectedTile = null; // Deselect when changing plant
  });
}

function createSellButton(x, y) {
  let sellButton = createButton("Sell");
  sellButton.position(x, y);
  sellButton.mousePressed(() => {
    if (selectedTile) {
      let tile = grid[selectedTile.x][selectedTile.y];
      if (tile.planted) {
        let plantType = tile.planted;
        let sellPrice = plants[plantType].sellPrice;
        playerMoney += sellPrice;
        grid[selectedTile.x][selectedTile.y].planted = null;
        grid[selectedTile.x][selectedTile.y].growth = 0;
        console.log(`Sold ${plantType} for $${sellPrice}`);
        selectedTile = null; // Deselect after selling
      } else {
        console.log("No plant selected to sell.");
      }
    } else {
      console.log("Select a tile to sell.");
    }
  });
}